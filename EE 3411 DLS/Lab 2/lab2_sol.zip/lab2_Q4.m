%Mohammad
%LAB2 Q6
%*********************
clc; clear all; close all;

% integral(x = RC*dy/dt + y)
% 
% integral(x) = RC*(y(nT)-y((n-1)T) + integral(y)
% 
% T/2*[xt(nT)+xt((n-1)T)]=RC*(y(nT)-y((n-1)T)+T/2*[yt(nT)+yt((n-1)T)]
%
% yt(nT)*[2RC+T] + yt((n-1)T)*[T-2RC] = xt(nT)*T + xt((n-1)T)*T
% 
% yt(nT) = [xt(nT) + xt((n-1)T)]*T/(2RC+T) + yt((n-1)T)]*(2RC-T)/(2RC+T)

R = 2e3; %2K Ohms
C = 10e-6; %10 uF

dt = 0.001;
t = 0.6:dt:1.6;

xt = t .* (us(t - 0.8) - us(t - 1.1));

T = dt;
yt = zeros(size(xt));
yt(1) = 0;

for n = 2:size(xt,2)
    yt(n) = T/(2*R*C+T)*(xt(n) + xt(n-1)) ...
            + yt(n-1)*(2*R*C-T)/(2*R*C+T);
end

figure(1)
plot(t,xt,t,yt)
