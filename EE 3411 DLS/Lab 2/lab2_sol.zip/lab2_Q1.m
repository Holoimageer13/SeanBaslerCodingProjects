%Mohammad
%Lab2 Q1
%********************
clc; clear all; close all;

dt = 0.001;
t = -0.1:dt:0.1;

it1 = 2.4*cos(15*pi*t-0.8);
it2 = 4.2*cos(15*pi*t-1.9);
it3 = it1 + it2;

ref = cos(15*pi*t);

figure(1);
plot(t,it1,t,it2,t,it3,t,ref)
legend('it1', 'it2', 'it3', 'ref')
grid on

%*************************************
[m1, loc1] = max(it1(t>0));
[m2, loc2] = max(it2(t>0));
[m3, loc3] = max(it3(t>0));

dly1 = loc1*dt
dly2 = loc2*dt
dly3 = loc3*dt

