%Mohammad
%LAB2 Q6
%*********************
clc; clear all; close all;

dt = 0.001;
T = dt;
t = 0:dt:10;

%**********************************************
% you can generate xt in 2 methods.
% if you want to check method 2 please 
% comment method 1 (lines: 17~20) and  
% uncomment method 2 (lines: 23,24) before running the code.

% method 1: using logical operations
% xt = 0 .* t + ...
%      (-3*t+6 ) .* ((t >= 1) & (t < 2)) + ...
%      (-3*t+9 ) .* ((t >= 2) & (t < 3)) + ...
%      (-3*t+12) .* ((t >= 3) & (t < 4));

% mtheod 2: using unit step and unit ramp functions
xt =  3*us(t-1) - 3*ur(t-1) ...
    + 3*us(t-2) + 3*us(t-3) + 3*ur(t-4);
%**********************************************

% ay(nT) + by((n-1)T) + cy((n-2)T) = dx(nT) + ex((n-1)T)
% y(nT) = (dx(nT) + ex((n-1)T) - by((n-1)T) - cy((n-2)T))/a
a =  0.3/T^2 + 0.4/T + 0.8;
b = -0.6/T^2 - 0.4/T;
c =  0.3/T^2;
d =  0.2/T + 0.9;
e = -0.2/T;

yt(1) = 2;
yt(2) = 2-0.35*T;
for n = 3:size(xt,2)
    yt(n) = (d*xt(n) + e*xt(n-1) - b*yt(n-1) - c*yt(n-2))/a;
end

    
figure(1);
plot(t,xt,t,yt)
legend('xt (input signal)','yt (output signal)');