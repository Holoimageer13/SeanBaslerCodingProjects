function [x,y,z] = example(w)
%EXAMPLE An example of a function.This function
%computes the square root, the square and 
%the mean of the values in a matrix w.
x = sqrt(w)
y = w .^ 2
z = mean(w)