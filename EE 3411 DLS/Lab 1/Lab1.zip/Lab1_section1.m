%Sean Basler
%Lab1 Section 1
%*****************
clc; clear all;

